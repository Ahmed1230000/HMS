<?php

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Livewire\Attributes\Title;
use Livewire\Component;

new #[Fillable(['layouts.dashboard'],#[Title('Two-Factor Authentication')])] class extends Component
{
    //
};
?>

<div>
    {{-- Very little is needed to make a happy life. - Marcus Aurelius --}}
</div>