<?php

namespace App\Domains\Pharmacy\Database\Factories;

use App\Domains\Pharmacy\Enums\MedicineStatusEnum;
use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Medicine;
use App\Models\User;

class MedicineFactory extends Factory
{
    protected $model = Medicine::class;

    public function definition(): array
    {
        return [
            'code' => fake()->unique()->numerify('MED-######'),
            'name' => fake()->words(2, true),
            'generic_name' => fake()->words(2, true),
            'manufacturer' => fake()->company(),

            'status' => MedicineStatusEnum::ACTIVE,

            'created_by' => User::factory(),
        ];
    }
}
