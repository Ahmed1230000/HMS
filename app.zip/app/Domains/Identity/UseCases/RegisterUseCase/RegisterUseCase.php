<?php

namespace App\Domains\Identity\UseCases\RegisterUseCase;

use App\Domains\User\Repositories\Contracts\User\UserRepositoryInterface;
use App\Domains\Identity\DTOs\Register\RegisterDTO;
use App\Domains\Identity\Exceptions\Login\InvalidCredentialsException;
use App\Domains\Identity\Service\CreateSessionService;
use App\Domains\User\DTOs\User\UserDTO;
use App\Domains\User\Entities\User\UserEntity;
use App\Domains\User\Events\User\SendWelcomeMessageEvent;
use App\Domains\User\Repositories\Contracts\HashPassword\HashPasswordRepositoryInterface;
use Illuminate\Auth\Events\Registered;

class RegisterUseCase
{
    /*
    |--------------------------------------------------------------------------
    | Constructor
    |--------------------------------------------------------------------------
    */

    public function __construct(
        private UserRepositoryInterface $repository,
        private HashPasswordRepositoryInterface $passwordHasher,
        private CreateSessionService $createSessionService,
    ) {}

    /*
    |--------------------------------------------------------------------------
    | Handle
    |--------------------------------------------------------------------------
    */

    public function execute(RegisterDTO $dto): UserEntity
    {
        $findEmail = $this->repository->findByEmail($dto->email->value());

        if ($findEmail) {
            throw new InvalidCredentialsException(
                'The email is already registered.'
            );
        }

        $hashedPassword = $this->passwordHasher->hashPassword($dto->password);

        $user = UserEntity::register(
            $dto->name,
            $dto->email,
            $hashedPassword,
        );

        $user = $this->repository->create($user);

        $userModel = $this->repository->findModel($user->id);

        $this->createSessionService->login($user);

        event(new SendWelcomeMessageEvent($userModel));

        return $user;
    }
}
