<?php

namespace App\Domains\User\Http\Resources\User;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Request;

class UserReadResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,

            // TODO: map model fields
            // 'name' => $this->name,

            // 🔥 relation example
            // 'owner' => UserResource::make($this->whenLoaded('owner')),

            // 🔥 collection example
            // 'items' => ItemResource::collection($this->whenLoaded('items')),

            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}